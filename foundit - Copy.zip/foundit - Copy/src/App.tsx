import { useState, useEffect } from 'react'
import {
  LayoutDashboard,
  AlertTriangle,
  Search as SearchIcon,
  FileText,
  Settings,
  LogOut,
  MapPin,
  Navigation,
  Clock,
  Phone,
  Minus,
  Plus,
  Locate,
  Bell,
  CheckCircle,
  AlertCircle,
  Zap,
  Info,
  X,
} from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────
type AppScreen = 'splash' | 'auth' | 'dashboard'
type SidebarTab = 'dashboard' | 'report' | 'find' | 'reports' | 'settings'

type NotificationType = 'match' | 'claim' | 'collection' | 'admin'
interface AppNotification {
  id: string
  type: NotificationType
  title: string
  body: string
  is_read: boolean
  created_at: string
  link?: string
}

const mockNotifications: AppNotification[] = [
  { id: 'n1', type: 'match', title: 'New Match Found!', body: 'A set of keys matching your report was found at Central Station.', is_read: false, created_at: '10m ago', link: '/matches/123' },
  { id: 'n2', type: 'claim', title: 'Claim Approved', body: 'Your claim for MacBook Pro has been approved. You can now collect it.', is_read: false, created_at: '2h ago', link: '/claims/456' },
  { id: 'n3', type: 'collection', title: 'Item Collected', body: 'You successfully collected the item. Thank you for using foundit!', is_read: true, created_at: '1d ago' },
  { id: 'n4', type: 'admin', title: 'System Update', body: 'We have updated our terms of service.', is_read: true, created_at: '2d ago' },
  { id: 'n5', type: 'match', title: 'Possible Match', body: 'We found a Golden Retriever that looks like your lost pet.', is_read: true, created_at: '3d ago', link: '/matches/124' },
]

// ─── Main App ─────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<AppScreen>('splash')
  const [loadingProgress, setLoadingProgress] = useState(0)

  // Splash loading
  useEffect(() => {
    if (screen !== 'splash') return
    const timer = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer)
          setTimeout(() => setScreen('auth'), 400)
          return 100
        }
        return Math.min(100, prev + 1)
      })
    }, 30)
    return () => clearInterval(timer)
  }, [screen])

  if (screen === 'splash') {
    return <SplashScreen progress={loadingProgress} />
  }

  if (screen === 'auth') {
    return <AuthScreen onLogin={() => setScreen('dashboard')} />
  }

  return <Dashboard />
}

// ─── Splash Screen ────────────────────────────────────────────────────────
function SplashScreen({ progress }: { progress: number }) {
  return (
    <div className="splash-screen-container">
      <div className="gestures-full-backdrop" aria-hidden="true">
        <img
          src="/hand-gestures.png"
          alt="Giving and receiving lost package"
          className="hand-gestures-art-fullscreen"
        />
        <div className="gesture-ripple-ring ring-a" />
        <div className="gesture-ripple-ring ring-b" />
      </div>

      <header className="brand-wordmark-container">
        <img src="/foundit-logo.png" alt="foundit" className="foundit-brand-logo" />
        <p className="brand-subtext">Connecting what's lost with who cares</p>
      </header>

      <div className="stage-spacer" />

      <footer className="loading-meter-section">
        <div className="status-label-row">
          <span className="status-text">
            {progress >= 100 ? 'Ready to explore' : 'Loading foundit...'}
          </span>
          <span className="progress-percentage">{progress}%</span>
        </div>
        <div
          className="progress-track"
          role="progressbar"
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          <div className="progress-fill orange-fill" style={{ width: `${progress}%` }}>
            <div className="progress-shimmer" />
          </div>
        </div>
        <div className="pulse-dots" aria-hidden="true">
          <span className="pulse-dot d1" />
          <span className="pulse-dot d2" />
          <span className="pulse-dot d3" />
        </div>
      </footer>
    </div>
  )
}

// ─── Auth Screen ──────────────────────────────────────────────────────────
function AuthScreen({ onLogin }: { onLogin: () => void }) {
  const [isLogin, setIsLogin] = useState(true)

  return (
    <div className="auth-screen-container auth-split-layout">
      <div className="auth-left-pane">
        <div className="gestures-full-backdrop auth-backdrop">
          <img
            src="/hand-gestures.png"
            alt="Giving and receiving lost package"
            className="hand-gestures-art-fullscreen auth-art"
          />
          <div className="gesture-ripple-ring ring-a" />
          <div className="gesture-ripple-ring ring-b" />
        </div>
      </div>

      <div className="auth-right-pane">
        <header className="brand-wordmark-container auth-brand-split">
          <img src="/foundit-logo.png" alt="foundit" className="foundit-brand-logo" />
        </header>

        <div className="auth-form-container form-split">
          <h1 className="auth-title split-title">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="auth-subtitle split-subtitle">
            {isLogin
              ? 'Sign in or create an account to continue'
              : 'Join foundit to connect with what matters'}
          </p>

          <button className="google-login-btn split-google-btn">
            <svg className="google-icon" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </button>

          <div className="auth-divider split-divider">
            <span>or</span>
          </div>

          <form className="auth-form" onSubmit={(e) => e.preventDefault()}>
            {!isLogin && (
              <input type="text" placeholder="Full Name" className="auth-input split-input" />
            )}
            <input type="email" placeholder="Email Address" className="auth-input split-input" />
            <input type="password" placeholder="Password" className="auth-input split-input" />

            <button
              type="button"
              className="auth-submit-btn split-submit-btn"
              onClick={onLogin}
            >
              {isLogin ? 'Sign In' : 'Sign Up'}
            </button>
          </form>

          <p className="auth-footer-text split-footer">
            {isLogin ? "Don't have an account? " : 'Already have an account? '}
            <a
              href="#"
              className="auth-link split-link"
              onClick={(e) => {
                e.preventDefault()
                setIsLogin(!isLogin)
              }}
            >
              {isLogin ? 'Sign Up' : 'Sign In'}
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── Dashboard ────────────────────────────────────────────────────────────
function Dashboard() {
  const [activeTab, setActiveTab] = useState<SidebarTab>('dashboard')
  const [searchQuery, setSearchQuery] = useState('')

  const navItems: { id: SidebarTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { id: 'report', label: 'Report It', icon: <AlertTriangle size={20} /> },
    { id: 'find', label: 'Find It', icon: <SearchIcon size={20} /> },
    { id: 'reports', label: 'My Reports', icon: <FileText size={20} /> },
  ]

  const branches = [
    { name: 'Downtown Office', address: '123 Main St, City Center', status: 'Open' },
    { name: 'Airport Terminal 2', address: 'Gate B, International Terminal', status: 'Open' },
    { name: 'Central Station', address: 'Platform 5, Railway Hub', status: 'Closed' },
    { name: 'University Campus', address: 'Student Center, Block A', status: 'Open' },
  ]

  return (
    <div className="dashboard-layout">
      {/* ── Sidebar ── */}
      <aside className="sidebar" id="main-sidebar">
        <div className="sidebar-inner">
          {/* Profile Section */}
          <div className="sidebar-profile">
            <div className="profile-avatar">
              <img src="/foundit-logo.png" alt="Profile" className="avatar-img" />
            </div>
            <div className="profile-info">
              <span className="profile-name">John Doe</span>
              <span className="profile-role">Member</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="sidebar-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                className={`sidebar-nav-item ${activeTab === item.id ? 'active' : ''}`}
                onClick={() => setActiveTab(item.id)}
                title={item.label}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Bottom Actions */}
          <div className="sidebar-bottom">
            <button className="sidebar-nav-item" title="Settings" id="nav-settings-btn">
              <span className="nav-icon"><Settings size={20} /></span>
              <span className="nav-label">Settings</span>
            </button>
            <button className="sidebar-nav-item logout-item" title="Log Out" id="nav-logout-btn">
              <span className="nav-icon"><LogOut size={20} /></span>
              <span className="nav-label">Log Out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <main className="dashboard-main">
        {/* Top Bar */}
        <header className="dashboard-topbar">
          <div className="topbar-search">
            <SearchIcon size={18} className="search-input-icon" />
            <input
              type="text"
              placeholder="Search for lost items, reports..."
              className="search-input"
              id="dashboard-search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="topbar-actions" style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '1.5rem', paddingRight: '1rem' }}>
            <div className="topbar-brand" style={{ margin: 0, display: 'flex', alignItems: 'center' }}>
              <span className="topbar-logo-text">found</span>
              <span className="topbar-logo-accent">it</span>
            </div>
            <NotificationBell />
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="dashboard-content">
          {/* Hero Section with BG Image */}
          <section className="dashboard-hero" id="dashboard-hero-section">
            <div className="hero-bg-image">
              <img src="/dashboard-bg.jpg" alt="" className="hero-bg" />
              <div className="hero-bg-overlay" />
            </div>
            <div className="hero-content">
              <div className="hero-text-block">
                <h1 className="hero-title">
                  Find &amp; Recover
                  <br />
                  <span className="hero-highlight">With</span> Ease
                </h1>
                <p className="hero-description">
                  Lost something? Found something? We bridge the gap between lost items and their rightful owners. Report, search, and recover — all in one place.
                </p>
              </div>
              <div className="hero-actions">
                <button
                  className="hero-btn hero-btn-report"
                  id="btn-report-it"
                  onClick={() => setActiveTab('report')}
                >
                  <AlertTriangle size={20} />
                  Report It
                </button>
                <button
                  className="hero-btn hero-btn-found"
                  id="btn-found-it"
                  onClick={() => setActiveTab('find')}
                >
                  <SearchIcon size={20} />
                  Found It
                </button>
              </div>
            </div>
          </section>

          {/* Stats Cards */}
          <section className="dashboard-stats">
            <div className="stat-card" id="stat-total-reports">
              <div className="stat-icon stat-icon-orange">
                <FileText size={22} />
              </div>
              <div className="stat-info">
                <span className="stat-value">1,247</span>
                <span className="stat-label">Total Reports</span>
              </div>
            </div>
            <div className="stat-card" id="stat-recovered">
              <div className="stat-icon stat-icon-green">
                <SearchIcon size={22} />
              </div>
              <div className="stat-info">
                <span className="stat-value">892</span>
                <span className="stat-label">Items Recovered</span>
              </div>
            </div>
            <div className="stat-card" id="stat-active">
              <div className="stat-icon stat-icon-blue">
                <AlertTriangle size={22} />
              </div>
              <div className="stat-info">
                <span className="stat-value">355</span>
                <span className="stat-label">Active Cases</span>
              </div>
            </div>
            <div className="stat-card" id="stat-branches">
              <div className="stat-icon stat-icon-purple">
                <MapPin size={22} />
              </div>
              <div className="stat-info">
                <span className="stat-value">24</span>
                <span className="stat-label">Our Branches</span>
              </div>
            </div>
          </section>

          {/* Recent Notifications List */}
          <section className="dashboard-notifications" id="notifications-section" style={{ padding: '0 2rem 2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '1.5rem' }}>
              <div className="section-header" style={{ margin: 0, padding: 0, textAlign: 'left' }}>
                <h2 className="section-title" style={{ textAlign: 'left' }}>Recent Notifications</h2>
                <p className="section-caption" style={{ textAlign: 'left' }}>Stay updated on your matches and claims</p>
              </div>
              <a href="#" style={{ fontSize: '0.875rem', color: 'var(--accent-color, #f97316)', textDecoration: 'none', fontWeight: 500, marginBottom: '0.25rem' }}>View all</a>
            </div>
            
            <div className="notifications-list" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {mockNotifications.map((notif) => (
                <div key={notif.id} style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '1rem', 
                  padding: '1rem', 
                  background: 'var(--surface, #fff)', 
                  borderRadius: '12px', 
                  border: '1px solid rgba(0,0,0,0.05)', 
                  borderLeft: notif.is_read ? '1px solid rgba(0,0,0,0.05)' : '4px solid var(--accent-color, #f97316)',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.02)',
                  cursor: 'pointer',
                  opacity: notif.is_read ? 0.7 : 1
                }}>
                  <div style={{ flexShrink: 0 }}>
                    {notif.type === 'match' && <Zap size={20} color="#f97316" />}
                    {notif.type === 'claim' && <AlertCircle size={20} color="#eab308" />}
                    {notif.type === 'collection' && <CheckCircle size={20} color="#22c55e" />}
                    {notif.type === 'admin' && <Info size={20} color="#64748b" />}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                      <span style={{ fontSize: '0.9rem', fontWeight: notif.is_read ? 500 : 600, color: '#222' }}>{notif.title}</span>
                      <span style={{ fontSize: '0.75rem', color: '#888', flexShrink: 0, marginLeft: '1rem' }}>{notif.created_at}</span>
                    </div>
                    <p style={{ margin: 0, fontSize: '0.875rem', color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {notif.body}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Recent Reports & Founds */}
          <section className="dashboard-recent" id="recent-section" style={{ padding: '0 2rem 2rem' }}>
            <div className="section-header">
              <h2 className="section-title">Recent Reports & Founds</h2>
              <p className="section-caption">Latest lost and found items in your area</p>
            </div>
            <div className="recent-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '1.5rem' }}>
              
              {/* Dummy Card 1 */}
              <div className="recent-card" style={{ background: 'var(--surface, #fff)', borderRadius: '16px', padding: '1.25rem', border: '1px solid rgba(0,0,0,0.05)', boxShadow: '0 4px 12px rgba(0,0,0,0.03)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#f97316', background: '#fff7ed', padding: '0.25rem 0.75rem', borderRadius: '999px' }}>Lost</span>
                  <span style={{ fontSize: '0.75rem', color: '#888' }}>2h ago</span>
                </div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '1.1rem', fontWeight: 600, color: '#222' }}>Golden Retriever</h4>
                <p style={{ margin: 0, fontSize: '0.875rem', color: '#666', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <MapPin size={14} color="#888" /> Downtown Park
                </p>
              </div>

              {/* Dummy Card 2 */}
              <div className="recent-card" style={{ background: 'var(--surface, #fff)', borderRadius: '16px', padding: '1.25rem', border: '1px solid rgba(0,0,0,0.05)', boxShadow: '0 4px 12px rgba(0,0,0,0.03)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#22c55e', background: '#f0fdf4', padding: '0.25rem 0.75rem', borderRadius: '999px' }}>Found</span>
                  <span style={{ fontSize: '0.75rem', color: '#888' }}>5h ago</span>
                </div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '1.1rem', fontWeight: 600, color: '#222' }}>Keys on Blue Lanyard</h4>
                <p style={{ margin: 0, fontSize: '0.875rem', color: '#666', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <MapPin size={14} color="#888" /> Central Station
                </p>
              </div>

              {/* Dummy Card 3 */}
              <div className="recent-card" style={{ background: 'var(--surface, #fff)', borderRadius: '16px', padding: '1.25rem', border: '1px solid rgba(0,0,0,0.05)', boxShadow: '0 4px 12px rgba(0,0,0,0.03)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#f97316', background: '#fff7ed', padding: '0.25rem 0.75rem', borderRadius: '999px' }}>Lost</span>
                  <span style={{ fontSize: '0.75rem', color: '#888' }}>1d ago</span>
                </div>
                <h4 style={{ margin: '0 0 0.5rem 0', fontSize: '1.1rem', fontWeight: 600, color: '#222' }}>MacBook Pro 16"</h4>
                <p style={{ margin: 0, fontSize: '0.875rem', color: '#666', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <MapPin size={14} color="#888" /> University Library
                </p>
              </div>

            </div>
          </section>

          {/* Branches Section (Grid Only) */}
          <section className="dashboard-branches" id="branches-section">
            <div className="section-header" style={{ textAlign: 'left' }}>
              <h2 className="section-title">Our Branches</h2>
              <p className="section-caption">Find your nearest foundit branch — we're everywhere you need us</p>
            </div>

            {/* Branch Cards */}
            <div className="branches-grid">
              {branches.map((branch, i) => (
                <div key={i} className="branch-card" id={`branch-card-${i}`}>
                  <div className="branch-icon-wrap">
                    <MapPin size={20} />
                  </div>
                  <div className="branch-info">
                    <span className="branch-name">{branch.name}</span>
                    <span className="branch-address">{branch.address}</span>
                    <span className="branch-hours">
                      <Clock size={12} />
                      {branch.status === 'Open' ? 'Mon–Sat, 9AM–6PM' : 'Closed today'}
                    </span>
                  </div>
                  <div className="branch-right">
                    <span className={`branch-status ${branch.status === 'Open' ? 'status-open' : 'status-closed'}`}>
                      {branch.status}
                    </span>
                    <button className="branch-call-btn" title="Call branch">
                      <Phone size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}

// ─── Notifications ────────────────────────────────────────────────────────
function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false)
  const unreadCount = mockNotifications.filter(n => !n.is_read).length

  return (
    <div style={{ position: 'relative' }}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        style={{ 
          background: 'none', border: 'none', cursor: 'pointer', 
          position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '0.5rem', borderRadius: '50%', color: '#444'
        }}
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span style={{
            position: 'absolute', top: '4px', right: '4px', background: '#ef4444', color: 'white',
            fontSize: '0.65rem', fontWeight: 'bold', borderRadius: '50%', width: '16px', height: '16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div style={{
          position: 'absolute', top: '100%', right: 0, marginTop: '0.5rem',
          width: '320px', background: '#fff', borderRadius: '12px',
          boxShadow: '0 10px 25px rgba(0,0,0,0.1)', border: '1px solid #eee',
          zIndex: 50, overflow: 'hidden'
        }}>
          <div style={{ padding: '1rem', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600 }}>Notifications</h3>
            <button onClick={() => setIsOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#888' }}><X size={16}/></button>
          </div>
          <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
            {mockNotifications.slice(0, 3).map((notif) => (
              <div key={notif.id} style={{ 
                padding: '1rem', borderBottom: '1px solid #eee', 
                background: notif.is_read ? '#fff' : '#fff7ed',
                cursor: 'pointer'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                  <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#222' }}>{notif.title}</span>
                  <span style={{ fontSize: '0.75rem', color: '#888' }}>{notif.created_at}</span>
                </div>
                <p style={{ margin: 0, fontSize: '0.8rem', color: '#666', lineHeight: 1.4 }}>
                  {notif.body}
                </p>
              </div>
            ))}
          </div>
          <a href="#" style={{ 
            display: 'block', padding: '0.75rem', textAlign: 'center', 
            fontSize: '0.875rem', color: '#f97316', textDecoration: 'none', 
            fontWeight: 500, background: '#fafafa' 
          }}>
            View all notifications
          </a>
        </div>
      )}
    </div>
  )
}
